// var myName = "abdhesh Rajput";
// var myNum = 99;
// var myBool = true;
// var myna;


// console.log(typeof(myName));
// console.log(typeof(myNum));
// console.log(typeof(myBool));
// console.log(typeof(myna));

// practice2

// console.log(10 + "20");
// console.log(9 - "5");
// console.log("java" + "script");
// console.log(" " + " ")
// console.log(" " + 0);
// console.log("abdhesh" - "rajput");
// console.log(true + true);
// console.log(true + false);
// console.log(false + true);
// console.log(false - true);

// practice3

console.log(NaN ===NaN);
console.log(Number.NaN === NaN);
console.log(isNaN(NaN));
console.log(isNaN(Number.NaN));