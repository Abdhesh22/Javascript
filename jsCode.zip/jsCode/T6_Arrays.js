// var myfriend = new Array; //it is optional
// var myfriend = ['ramesh','arjun','vishal','abdhesh','saurabh','deepak','abhishek']; //first is calls lower and last is upper first element's index is always 0.

// this is for loop
// for (let i = 0; i < myfriend.length; i++) {
//     console.log(myfriend[i]);
// }

//this is for in loop , its return index number of element
// for (let element in myfriend) {
//     console.log(element);
// }

// for(let element of myfriend){   //its will return the element
//     console.log(element);
// }

// myfriend.forEach(function(element,index,array){
//     console.log(element+" index: "+index+" "+array);
// });

// myfriend.forEach((element,index,array)=>{
//     console.log(element+" index: "+index+" "+array)
// })


//indexof()



//push() it return the new length of array and add elements at last position
// const animals = ['pigs','goats','sheep'];
// // animals.push('chicken');
// console.log(animals);

// animals.push('chicken','cat','dogs','cows');
// console.log(animals);

//unshift for adding element at starting

// const myNum = [1,2,3,45,55];

// // myNum.unshift(10,23);
// // console.log(myNum);
// myNum.pop();
// myNum.shift();
// console.log(myNum);

//practice set
const months = ['jan','march','april','june','july'];
//sol1: 
// months.splice(5,0,'Dec'); 
// console.log(months);

//sol2: return value of splice method: its returns the deleted data.

//sol3:
// const indexOfMonths = months.indexOf('march');
// if(indexOfMonths != -1){
//     const updateMonths = months.splice(indexOfMonths,1,'March');
// }
// else{
//     console.log('No such data found');
// }
// // const updateMonths = months.splice(1,1,'March');
// console.log(months);

// //sol4:
// months.splice(3,1);
// console.log(months);


// map ();
// const  array = [1,4,9,16,25];
// // num >9
// let newArr = array.map((currnetElement,index,arr)=>{
//         return currnetElement>9;
// })

// console.log(array);
// console.log(newArr);

// let newArray = array.map((currnetElement,index,arr)=>{
//     return `index of no = ${index} and the value is ${currnetElement} belong to ${arr}`;
// })

// console.log(array);
// console.log(newArray);


// sol:1 find the sqrt of elements:
// let arr=[25,36,49,64,81,100];

// let arrsqr = arr.map((currentElement)=>{
//     return Math.sqrt( currentElement);
// })

// console.log(arrsqr);


// sol2: multily by 2 and return greater than 10 Element
// let arr=[2,3,4,5,6,7,8];

// let arrNew = arr.map((curnElemnt)=>{
//     return curnElemnt*2;
// }).filter((curnElemnt)=>{
//     return curnElemnt>10;
// })

// console.log(arrNew);

//reduce method
// let arr= [2,3,45,6];

// let arrsum = arr.reduce((accumulator,ele)=>{
//     return accumulator +=ele;
// })
// console.log(arrsum);
