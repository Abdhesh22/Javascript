// // practice
// var year = 2020;

// if (year%4===0) {
//     if (year%100===0) {
//         if (year%400===0) {
//             console.log("the"+year+ " is leap year");
//         }
//         else{
//             console.log("the "+year+ " is not a leap year");
//         }
//     }
//     else{
//         console.log("the "+year+" is leap year");         
//     }
// } else {
//     console.log("the " +year+" is not a leap year");
// }

// truthy and falsy 0,"",undefined,null, NaN they all are falsy value means they return false.
// if (score = 0) {
//         console.log("Yay, we won the game");
// }
// else{
//     console.log("Omg, we loss the game");
// }

// ternary operator
// var age=20;

// var vote = (age>=18) ? "you can vote.":"you can't vote";
// console.log(vote);
// var area = "circle";
// var PI = 3.142,l=5,b=4,r=3;
// switch (area) {
//     case 'circle':
//         console.log("Area of circle is: " + PI *r**2);
//         break;
//     case 'rectangle':
//         console.log("Area of Rectangle is: "+ l*b);
//         break;
//     default:
//         console.log("Please enter valid value");
//         break;
// }

for (let index = 1; index <=10; index++) {
    var num = 10;
    console.log(num + " * " +index +" = " + num *index);
}
