// qeus2
// var myphoneNumber = "89237w0240";
// console.log(myphoneNumber);
// console.log(typeof(myphoneNumber));
// if(!isNaN(myphoneNumber)){
//     console.log("Number registered sucessfull");
// }
// else{
//     console.log("Enter valid number");
// }


// qeus3 diff between == and ===
var x = 5;
var y = '5';

console.log(`using x == y : ${x==y}`);
console.log(`using x === y : ${x===y}`);    