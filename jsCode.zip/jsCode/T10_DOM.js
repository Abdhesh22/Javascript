//selecting an element in DOM

const firstchild = document.body.firstElementChild.firstElementChild;
firstchild.style.color ="RED";


const secondchild = document.body.querySelector(".child-2");
secondchild.style.color = "yellow";