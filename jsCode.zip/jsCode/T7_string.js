// const myBioData =  `I am Abdhesh Rajput`;
// console.log(myBioData.indexOf("Abdhesh")); //note this is case sensitive;
// console.log(myBioData.lastIndexOf("Abdhesh",15my

// let sData = myBioData.search("Abdhesh");
// console.log(sData);

//extracting string parts
// 1.slice();
// var str = "Apple, Banana, Kiwi, Mango";
// let res1 = str.slice(0,5);
// let res2 = str.slice(7,-2);
// console.log(res1);
// console.log(res2)

//challenge time:
// let myTweets = "abdhesh rajput";
// let myActualTweet = myTweets.slice(0,280);
// console.log(myActualTweet);
// console.log(myTweets.length);

//subString Method
// var str = "Apple, Banana, Kiwi, Mango";
// let res1 = str.substring(0,5);
// let res2 = str.substring(7,-2); //negative not allowed but in this case substring count from 0 to 7 position
// console.log(res);

// var str = "Apple, Banana, Kiwi, Mango";
// let res1 = str.substr(0,4);
// let res2 = str.substr(-2);  //extracing last two characters
// console.log(res1);
// console.log(res2);

// var str = "I am abdhesh Rajput abdhesh";
// var newStr = str.replace("abdhesh","Abdhesh");
// console.log(newStr);

// Extracting character method.

let str ="HELLO WORLD";
// console.log(str.charAt(0));

// console.log(str.charCodeAt(0)); //it's return the unicode of the 

//challenge time.
//return the unicode of the last character of string.
// let lastChar = str.length -1;
// console.log(str.charCodeAt(lastChar));

// property Access
// console.log(str[0]);


// other useful methods;
// let myName = "Abdhesh Kumar";
// let fname = "Abdhesh";
// let lname = "rajput";
// console.log(myName.toLowerCase());
// console.log(myName.toUpperCase());
// console.log(fname.concat(lname));
// console.log(fname.concat(" ",lname));
// console.log(fname + lname);
// console.log(`First name ${fname} and last name ${lname}`);



// var trimstr = "           HELLO WORLD               ";
// console.log(trimstr.trim());


// converting string into Array

var txt = "a,b,c,d,|,e,f,g";
console.log(txt.split(","));
console.log(txt.split(" "));
console.log(txt.split("|"));






