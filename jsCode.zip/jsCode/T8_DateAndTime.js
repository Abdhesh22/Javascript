// there are 4 ways to create a new date object
// new Date();
// new Date(year,months,day,hours,minutes,seconds,miliseconds);
//it takes 7 args.
// new Date(miliseconds);
//we can't avoid month section
// new Date(Date String);

// new Date()
// date objects are created with the new Date() constructor.

// let currDate = new Date();
// console.log(currDate);

// console.log(Date.now());

// let d = new Date(2021,11,12,21,10,30,0);
// console.log(d.toLocaleString());

// let d = new Date(2018,2,3);
// console.log(d.toLocaleString());

const currDate = new Date();
//getDate().
// console.log(currDate.toLocaleString());
// console.log(currDate.getDate());
// console.log(currDate.getMonth());
// console.log(currDate.getFullYear());
// console.log(currDate.getDay())

//setDate()
console.log(currDate.setFullYear(2021));
console.log(currDate.setFullYear(2021,9,5));
console.log(currDate.setMonth(7));
console.log(currDate.setDate(5));
console.log(currDate.toLocaleString());