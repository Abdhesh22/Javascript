var _myName = "Abdhesh";
var _my__Name = "Rajput";
// var 1myName = "abdhesh" this is not allowed in js; 
var $_myName = "kumar";
console.log($_myName);