// function sum(a,b) {
//     return total = a+b;
// }

// var funcexp = sum(10,23);
// console.log(funcexp);

// anonymous function  function without a name;

// var funexp = function(a,b){
//     return  total = a+b;
// }

// console.log(funexp(5,15));
var funexp = function(a,b){
    return  total = a+b;
}

var sum = funexp(10,34);
console.log(sum);