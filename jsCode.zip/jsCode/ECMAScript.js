// function bioData(params) {
//     var myName = "Abdhesh";
//     console.log(myName);
//     if (true) {
//         var myLastName = "Rajput";
//         console.log("inner " + myLastName);
//         console.log("inner " + myName);
//     }
//     console.log("innerOuter " + myLastName);    
// }
// bioData();

// function bioData(params) {  //let is use for block.
//     let myName = "Abdhesh";
//     console.log(myName);
//     if (true) {
//         let myLastName = "Rajput";
//         console.log("inner " + myLastName);
//         console.log("inner " + myName);
//     }
//     console.log("innerOuter " + myLastName);    
// }
// bioData();


// const sum = () => {
//     //this is fat arrow function
//     let a= 5,b=6;
//     return `the sum of a and b is ${a+b}`;
// } 
const sum = () => {`the sum of a and b is ${(a=5)+(b=6)}`};  //if we have only one line of code than doesn't need of return keyword to return the value. 
const sum = () => `the sum of a and b is ${(a=5)+(b=6)}`;  //if we have only one line of code than doesn't need of return keyword to return the value. also we {} not neccesary. 
//in fat arrow function we can't use this keyword
console.log(sum());