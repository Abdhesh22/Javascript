var x =5;
var y =5;

// console.log("is x and y are eqaul" + x == y);
console.log(`is x and y is eqaul: ${x==y}`);

var x = 5;
var newx = --x + 5;
var y = 5;
var newy = y++ + 5;
console.log(x);
console.log(newx);

console.log(y);
console.log(newy);

// pratice4
// sol1:
console.log(2*3);
// sol2
console.log(5 + "abdhesh");
// sol3
var a = 5;
var b =10;
// var temp = a;
// a= b;
// b =temp;
// console.log(a);
// console.log(b);
// sol4
b = a+b;
a = b-a;
b = b-a;
console.log(a);
console.log(b);